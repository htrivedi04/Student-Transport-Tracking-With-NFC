package com.harshit.studenttranstrack;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.net.Uri;
import android.text.method.ScrollingMovementMethod;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;
 
public class WebServiceActivity extends Activity {
	
	String studlist;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	
    	
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.webservice);
        studlist = this.getIntent().getStringExtra("studlist");
        TextView mailtext = (TextView) findViewById(R.id.students);
        TextView mailbody = (TextView) findViewById(R.id.emailtext);
        
        mailbody.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY); 
        mailbody.setMovementMethod(new ScrollingMovementMethod());
        mailbody.setText("Here is the list for Transport Tracking For Today: \n" + studlist);
        
        Button send=(Button) findViewById(R.id.emailsendbutton);
        
        send.setOnClickListener(new OnClickListener() {
                       
                        @Override
                        public void onClick(View view) {
                        	Log.i("Send email", "");
                        	String[] TO = {"h.trivedi04@gmail.com"};	
                            String[] CC = {"h.trivedi04@gmail.com", "harshit.trivedi22@gmail.com"};
                            Intent emailIntent = new Intent(Intent.ACTION_SEND);
                            emailIntent.setData(Uri.parse("mailto:"));
                            emailIntent.setType("text/plain");

                            emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
                            emailIntent.putExtra(Intent.EXTRA_CC, CC);
                            emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Student Transport Track For Today");
                            emailIntent.putExtra(Intent.EXTRA_TEXT, "Student Transport Tracking List For Today:\n" + studlist);

                            try {
                               startActivity(Intent.createChooser(emailIntent, "Send mail..."));
                               finish();
                               Log.i("Finished sending email...", "");
                            } catch (android.content.ActivityNotFoundException ex) {
                               Toast.makeText(WebServiceActivity.this, 
                               "There is no email client installed.", Toast.LENGTH_SHORT).show();
                            }
                        }
                });
    }
    

     @Override
     public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
     }
}






