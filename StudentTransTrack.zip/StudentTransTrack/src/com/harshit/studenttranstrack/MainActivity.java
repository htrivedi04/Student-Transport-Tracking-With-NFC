package com.harshit.studenttranstrack;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);  


        Button buttonwritetag = (Button) findViewById(R.id.buttonwritetag);
        buttonwritetag.setOnClickListener(new View.OnClickListener() 
        {
           public void onClick(View view) {
                Intent myIntent = new Intent( view.getContext(), TransportationWriterActivity.class);
                startActivityForResult(myIntent, 0);
            }
        });
               

        Button buttontranstrack = (Button) findViewById(R.id.buttontranstrack);
        buttontranstrack.setOnClickListener(new View.OnClickListener() 
        {
           public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), TransportationActivity.class);
                startActivityForResult(myIntent, 0);
            }
        });  
            

        Button buttonquit	= (Button)this.findViewById(R.id.buttonquit);
        buttonquit.setOnClickListener(new android.view.View.OnClickListener() 
        {
        	public void onClick(View v) {
        		finish();
        	}
        });        
        
        
    }
}